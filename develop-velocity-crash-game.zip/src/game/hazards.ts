import { HARD_HAZARDS, IMPOSSIBLE_HAZARDS, type HazardKind } from "./content";

export type HazardDifficulty = "Easy" | "Medium" | "Hard" | "Impossible";

export interface TrackHazard {
  id: string;
  kind: HazardKind;
  x: number;
  width: number;
  lane: "player" | "bot" | "both";
  phase: number;
  period: number;
  active: boolean;
  hitPlayer?: boolean;
  hitBot?: boolean;
}

export interface HazardRuntime {
  items: TrackHazard[];
  playerSlide: number;
  botSlide: number;
  playerBrakeMul: number;
  botBrakeMul: number;
  playerSpeedMul: number;
  botSpeedMul: number;
  playerNudge: number;
  botNudge: number;
}

function makeId(kind: HazardKind, index: number): string {
  return `${kind}-${index}`;
}

export function createHazards(difficulty: HazardDifficulty): HazardRuntime {
  const empty: HazardRuntime = {
    items: [],
    playerSlide: 0,
    botSlide: 0,
    playerBrakeMul: 1,
    botBrakeMul: 1,
    playerSpeedMul: 1,
    botSpeedMul: 1,
    playerNudge: 0,
    botNudge: 0,
  };

  if (difficulty !== "Hard" && difficulty !== "Impossible") return empty;

  const items: TrackHazard[] = [];

  if (difficulty === "Hard" || difficulty === "Impossible") {
    const bananaCount = difficulty === "Hard" ? 3 : 4;
    for (let i = 0; i < bananaCount; i += 1) {
      items.push({
        id: makeId("banana", i),
        kind: "banana",
        x: 18 + i * (difficulty === "Hard" ? 9 : 8) + Math.random() * 2.2,
        width: 2.4,
        lane: i % 2 === 0 ? "player" : "both",
        phase: Math.random() * Math.PI * 2,
        period: 1,
        active: true,
      });
    }

    const oilCount = difficulty === "Hard" ? 2 : 3;
    for (let i = 0; i < oilCount; i += 1) {
      items.push({
        id: makeId("oil", i),
        kind: "oil",
        x: 24 + i * 11 + Math.random() * 3,
        width: 3.2,
        lane: "player",
        phase: 0,
        period: 1,
        active: true,
      });
    }
  }

  if (difficulty === "Impossible") {
    items.push({
      id: makeId("barrier", 0),
      kind: "barrier",
      x: 33,
      width: 4.5,
      lane: "both",
      phase: 0,
      period: 1.8,
      active: true,
    });
    items.push({
      id: makeId("pulse-gate", 0),
      kind: "pulse-gate",
      x: 41,
      width: 5,
      lane: "both",
      phase: 0.4,
      period: 1.35,
      active: true,
    });
    items.push({
      id: makeId("surge-wall", 0),
      kind: "surge-wall",
      x: 28,
      width: 3.5,
      lane: "player",
      phase: 0.2,
      period: 2.1,
      active: true,
    });
    items.push({
      id: makeId("timing-flare", 0),
      kind: "timing-flare",
      x: 37.5,
      width: 2.8,
      lane: "player",
      phase: 0.8,
      period: 1.6,
      active: true,
    });
  }

  return { ...empty, items };
}

export function activeHazardKinds(difficulty: HazardDifficulty): HazardKind[] {
  if (difficulty === "Hard") return HARD_HAZARDS.map((h) => h.kind);
  if (difficulty === "Impossible") {
    return Array.from(new Set(IMPOSSIBLE_HAZARDS.map((h) => h.kind)));
  }
  return [];
}

function overlaps(x: number, hazard: TrackHazard): boolean {
  return Math.abs(x - hazard.x) <= hazard.width * 0.5;
}

export function stepHazards(
  runtime: HazardRuntime,
  elapsed: number,
  dt: number,
  playerX: number,
  botX: number,
  playerBraking: boolean,
  botBraking: boolean,
): void {
  runtime.playerSlide = Math.max(0, runtime.playerSlide - dt);
  runtime.botSlide = Math.max(0, runtime.botSlide - dt);
  runtime.playerBrakeMul = 1;
  runtime.botBrakeMul = 1;
  runtime.playerSpeedMul = 1;
  runtime.botSpeedMul = 1;
  runtime.playerNudge = 0;
  runtime.botNudge = 0;

  for (const hazard of runtime.items) {
    if (hazard.kind === "barrier") {
      hazard.x = 30 + Math.sin(elapsed * (Math.PI * 2) / hazard.period + hazard.phase) * 7;
      hazard.active = true;
    } else if (hazard.kind === "pulse-gate") {
      const wave = (Math.sin(elapsed * (Math.PI * 2) / hazard.period + hazard.phase) + 1) * 0.5;
      hazard.active = wave > 0.42;
    } else if (hazard.kind === "surge-wall") {
      hazard.x = 22 + ((elapsed * 11) % 24);
      hazard.active = true;
    } else if (hazard.kind === "timing-flare") {
      const wave = (Math.sin(elapsed * (Math.PI * 2) / hazard.period + hazard.phase) + 1) * 0.5;
      hazard.active = wave > 0.55;
    }

    if (!hazard.active) continue;

    const hitPlayer = (hazard.lane === "player" || hazard.lane === "both") && overlaps(playerX, hazard);
    const hitBot = (hazard.lane === "bot" || hazard.lane === "both") && overlaps(botX, hazard);

    if (hitPlayer && !hazard.hitPlayer) {
      hazard.hitPlayer = true;
      applyHit(runtime, "player", hazard.kind, playerBraking);
    } else if (!hitPlayer) {
      hazard.hitPlayer = false;
    }

    if (hitBot && !hazard.hitBot) {
      hazard.hitBot = true;
      applyHit(runtime, "bot", hazard.kind, botBraking);
    } else if (!hitBot) {
      hazard.hitBot = false;
    }

    // Continuous modifiers while overlapping dynamic hazards
    if (hitPlayer) {
      if (hazard.kind === "oil") runtime.playerBrakeMul = Math.min(runtime.playerBrakeMul, 0.72);
      if (hazard.kind === "pulse-gate" && hazard.active) runtime.playerSpeedMul = Math.min(runtime.playerSpeedMul, 0.82);
      if (hazard.kind === "barrier") runtime.playerNudge += Math.sin(elapsed * 18) * 0.015;
      if (hazard.kind === "surge-wall") runtime.playerBrakeMul = Math.min(runtime.playerBrakeMul, 0.64);
      if (hazard.kind === "timing-flare" && hazard.active) runtime.playerSpeedMul = Math.min(runtime.playerSpeedMul, 0.9);
    }
    if (hitBot) {
      if (hazard.kind === "oil") runtime.botBrakeMul = Math.min(runtime.botBrakeMul, 0.72);
      if (hazard.kind === "pulse-gate" && hazard.active) runtime.botSpeedMul = Math.min(runtime.botSpeedMul, 0.82);
      if (hazard.kind === "barrier") runtime.botNudge += Math.sin(elapsed * 18) * 0.015;
      if (hazard.kind === "surge-wall") runtime.botBrakeMul = Math.min(runtime.botBrakeMul, 0.64);
    }
  }

  if (runtime.playerSlide > 0) {
    runtime.playerNudge += Math.sin(elapsed * 26) * 0.04;
    runtime.playerBrakeMul = Math.min(runtime.playerBrakeMul, 0.78);
  }
  if (runtime.botSlide > 0) {
    runtime.botNudge += Math.sin(elapsed * 26 + 1.2) * 0.035;
    runtime.botBrakeMul = Math.min(runtime.botBrakeMul, 0.8);
  }
}

function applyHit(
  runtime: HazardRuntime,
  side: "player" | "bot",
  kind: HazardKind,
  braking: boolean,
): void {
  if (kind === "banana") {
    if (side === "player") {
      runtime.playerSlide = Math.max(runtime.playerSlide, 0.55);
      runtime.playerNudge += braking ? 0.08 : 0.12;
    } else {
      runtime.botSlide = Math.max(runtime.botSlide, 0.45);
      runtime.botNudge += 0.08;
    }
  }
  if (kind === "oil") {
    if (side === "player") runtime.playerBrakeMul = Math.min(runtime.playerBrakeMul, 0.7);
    else runtime.botBrakeMul = Math.min(runtime.botBrakeMul, 0.72);
  }
  if (kind === "timing-flare" && side === "player") {
    runtime.playerSlide = Math.max(runtime.playerSlide, 0.28);
  }
}
