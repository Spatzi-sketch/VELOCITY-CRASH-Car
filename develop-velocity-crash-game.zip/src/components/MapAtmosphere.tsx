import type { CSSProperties } from "react";
import { getMap, type ArenaMapId } from "../game/content";

export function MapAtmosphere({ mapId, compact = false }: { mapId: ArenaMapId; compact?: boolean }) {
  const map = getMap(mapId);
  const style = {
    "--map-accent": map.accent,
    "--map-secondary": map.secondary,
    "--map-sky": map.sky,
    "--map-ground": map.ground,
    "--map-glow": map.glow,
    "--map-particle": map.particle,
  } as CSSProperties;

  return (
    <div className={`map-atmosphere map-${mapId} ${compact ? "is-compact" : ""}`} style={style} aria-hidden="true">
      <div className="map-sky" />
      <div className="map-glow-orb" />
      <div className="map-silhouettes">
        {mapId === "cherry-blossom" && (
          <>
            <span className="sil sil-mountain left" />
            <span className="sil sil-mountain right" />
            <span className="sil sil-temple" />
            <span className="sil sil-tree left" />
            <span className="sil sil-tree right" />
            {Array.from({ length: compact ? 8 : 16 }, (_, i) => (
              <i key={i} className="petal" style={{ left: `${(i * 13) % 100}%`, animationDelay: `${(i % 7) * 0.35}s` }} />
            ))}
          </>
        )}
        {mapId === "city" && (
          <>
            {Array.from({ length: compact ? 8 : 14 }, (_, i) => (
              <span key={i} className="sil sil-building" style={{ left: `${4 + i * 7}%`, height: `${28 + ((i * 17) % 42)}%`, animationDelay: `${i * 0.08}s` }} />
            ))}
            <span className="sil sil-sign left" />
            <span className="sil sil-sign right" />
          </>
        )}
        {mapId === "mountain" && (
          <>
            <span className="sil sil-peak a" />
            <span className="sil sil-peak b" />
            <span className="sil sil-peak c" />
            <span className="sil sil-forest" />
          </>
        )}
        {mapId === "coastal" && (
          <>
            <span className="sil sil-ocean" />
            <span className="sil sil-cliff left" />
            <span className="sil sil-cliff right" />
            <span className="sil sil-palm left" />
            <span className="sil sil-palm right" />
          </>
        )}
        {mapId === "desert" && (
          <>
            <span className="sil sil-dune a" />
            <span className="sil sil-dune b" />
            <span className="sil sil-rock" />
            <span className="sil sil-heat" />
          </>
        )}
        {mapId === "snow" && (
          <>
            <span className="sil sil-peak a cold" />
            <span className="sil sil-peak b cold" />
            <span className="sil sil-peak c cold" />
            {Array.from({ length: compact ? 10 : 18 }, (_, i) => (
              <i key={i} className="snowflake" style={{ left: `${(i * 11) % 100}%`, animationDelay: `${(i % 9) * 0.28}s` }} />
            ))}
          </>
        )}
        {mapId === "aurora" && (
          <>
            <span className="sil sil-aurora a" />
            <span className="sil sil-aurora b" />
            <span className="sil sil-stars" />
          </>
        )}
        {mapId === "neon-grid" && (
          <>
            <span className="sil sil-grid-flare" />
            <span className="sil sil-horizon" />
          </>
        )}
      </div>
      <div className="map-ground" />
    </div>
  );
}
