import type { CSSProperties } from "react";
import { ARENA_MAPS, PAINTS, type ArenaMapId, type Language, type PaintId } from "../game/content";
import { mapDesc, mapName, paintName, t } from "../game/i18n";
import { MapAtmosphere } from "./MapAtmosphere";

interface GarageModalProps {
  lang: Language;
  coins: number;
  unlockedMaps: ArenaMapId[];
  unlockedPaints: PaintId[];
  selectedMap: ArenaMapId;
  selectedPaint: PaintId;
  tab: "maps" | "paints";
  onTab: (tab: "maps" | "paints") => void;
  onSelectMap: (id: ArenaMapId) => void;
  onSelectPaint: (id: PaintId) => void;
  onUnlockMap: (id: ArenaMapId) => void;
  onUnlockPaint: (id: PaintId) => void;
  onClose: () => void;
}

export function GarageModal({
  lang,
  coins,
  unlockedMaps,
  unlockedPaints,
  selectedMap,
  selectedPaint,
  tab,
  onTab,
  onSelectMap,
  onSelectPaint,
  onUnlockMap,
  onUnlockPaint,
  onClose,
}: GarageModalProps) {
  return (
    <div className="modal-backdrop" role="presentation" onPointerDown={onClose}>
      <section
        className="garage-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="garage-title"
        onPointerDown={(event) => event.stopPropagation()}
      >
        <div className="modal-heading garage-heading">
          <div>
            <span className="eyebrow">{t(lang, "garage")}</span>
            <h2 id="garage-title">{t(lang, "garageTitle")}</h2>
            <p>{t(lang, "garageSub")}</p>
          </div>
          <div className="garage-heading-side">
            <div className="coin-pill large"><i /> {coins.toLocaleString()} <span>{t(lang, "coins")}</span></div>
            <button className="icon-button" onClick={onClose} aria-label={t(lang, "close")}>X</button>
          </div>
        </div>

        <div className="garage-tabs">
          <button type="button" className={tab === "maps" ? "is-selected" : ""} onClick={() => onTab("maps")}>{t(lang, "maps")}</button>
          <button type="button" className={tab === "paints" ? "is-selected" : ""} onClick={() => onTab("paints")}>{t(lang, "paints")}</button>
        </div>

        {tab === "maps" ? (
          <div className="garage-grid maps-grid">
            {ARENA_MAPS.map((map) => {
              const owned = unlockedMaps.includes(map.id);
              const selected = selectedMap === map.id;
              return (
                <article key={map.id} className={`map-card ${owned ? "is-owned" : "is-locked"} ${selected ? "is-selected" : ""}`}>
                  <div className="map-card-preview">
                    <MapAtmosphere mapId={map.id} compact />
                    {!owned && <div className="lock-badge">{t(lang, "locked")}</div>}
                    {map.free && <div className="starter-badge">{t(lang, "starter")}</div>}
                  </div>
                  <div className="map-card-body">
                    <h3>{mapName(lang, map.id)}</h3>
                    <p>{mapDesc(lang, map.id)}</p>
                    <div className="map-card-meta">
                      {owned ? (
                        <span className="owned-tag">{t(lang, "owned")}</span>
                      ) : (
                        <span className="price-tag"><i /> {map.price}</span>
                      )}
                    </div>
                    {owned ? (
                      <button type="button" className={`primary-action ${selected ? "is-quiet" : ""}`} onClick={() => onSelectMap(map.id)}>
                        {selected ? t(lang, "selected") : t(lang, "select")}
                      </button>
                    ) : (
                      <button
                        type="button"
                        className="secondary-button"
                        disabled={coins < map.price}
                        onClick={() => onUnlockMap(map.id)}
                      >
                        {coins < map.price ? t(lang, "notEnough") : `${t(lang, "unlock")} · ${map.price}`}
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="garage-grid paints-grid">
            {PAINTS.map((paint) => {
              const owned = unlockedPaints.includes(paint.id);
              const selected = selectedPaint === paint.id;
              return (
                <article key={paint.id} className={`paint-card ${owned ? "is-owned" : "is-locked"} ${selected ? "is-selected" : ""}`}>
                  <div className="paint-swatch" style={{ "--swatch": paint.hex } as CSSProperties}>
                    <span />
                    {paint.rare && <em>{t(lang, "rare")}</em>}
                  </div>
                  <div className="paint-card-body">
                    <h3>{paintName(lang, paint.id)}</h3>
                    <div className="map-card-meta">
                      {owned ? <span className="owned-tag">{t(lang, "owned")}</span> : <span className="price-tag"><i /> {paint.price || t(lang, "free")}</span>}
                    </div>
                    {owned ? (
                      <button type="button" className={`primary-action ${selected ? "is-quiet" : ""}`} onClick={() => onSelectPaint(paint.id)}>
                        {selected ? t(lang, "selected") : t(lang, "select")}
                      </button>
                    ) : (
                      <button
                        type="button"
                        className="secondary-button"
                        disabled={coins < paint.price}
                        onClick={() => onUnlockPaint(paint.id)}
                      >
                        {coins < paint.price ? t(lang, "notEnough") : `${t(lang, "unlock")} · ${paint.price}`}
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
