# Velocity Crash

Velocity Crash is a Vite and React browser game.

## Local development

```bash
npm install
npm run dev
```

## Vercel deployment

1. Push the repository with `package.json`, `vercel.json`, `index.html`, `src/`, and `public/` at the repository root.
2. Import the GitHub repository in Vercel.
3. Set **Root Directory** to `./`.
4. Use **Framework Preset: Vite**.
5. Keep **Build Command** as `npm run build` and **Output Directory** as `dist`.
6. Redeploy without the previous build cache if an older deployment returned 404.

`vercel.json` contains the SPA fallback to `/index.html`, so direct requests and refreshes resolve correctly.